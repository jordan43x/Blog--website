export interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: Author;
  date: string;
  readingTime: number;
  category: string;
  tags: string[];
  imageUrl: string;
  featured?: boolean;
}

export interface Author {
  id: string;
  name: string;
  avatar: string;
  bio: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}