import React from 'react';
import { Post } from '../types';
import { Clock, Calendar, Share2, Facebook, Twitter, Linkedin } from 'lucide-react';

interface PostDetailProps {
  post: Post;
}

const PostDetail: React.FC<PostDetailProps> = ({ post }) => {
  return (
    <article className="max-w-3xl mx-auto">
      {/* Header */}
      <header className="mb-8">
        <div className="flex flex-wrap gap-2 mb-4">
          <span className="inline-block px-3 py-1 text-xs font-semibold text-blue-800 bg-blue-100 dark:text-blue-200 dark:bg-blue-900/50 rounded-full">
            {post.category}
          </span>
          {post.tags.map((tag) => (
            <span 
              key={tag} 
              className="inline-block px-3 py-1 text-xs font-semibold text-gray-700 bg-gray-100 dark:text-gray-300 dark:bg-gray-700 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4 leading-tight">
          {post.title}
        </h1>
        
        <div className="flex flex-wrap items-center justify-between gap-4 text-gray-600 dark:text-gray-400 mb-6">
          <div className="flex items-center">
            <img 
              src={post.author.avatar} 
              alt={post.author.name} 
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <span className="block text-gray-900 dark:text-white font-medium">{post.author.name}</span>
              <div className="flex items-center text-sm">
                <Calendar size={14} className="mr-1" />
                <span>{post.date}</span>
                <span className="mx-2">•</span>
                <Clock size={14} className="mr-1" />
                <span>{post.readingTime} min read</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm">Share:</span>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
              <Facebook size={16} />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
              <Twitter size={16} />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
              <Linkedin size={16} />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
              <Share2 size={16} />
            </button>
          </div>
        </div>
      </header>
      
      {/* Featured Image */}
      <div className="mb-8 rounded-xl overflow-hidden shadow-lg">
        <img 
          src={post.imageUrl} 
          alt={post.title} 
          className="w-full h-auto object-cover"
        />
      </div>
      
      {/* Content */}
      <div 
        className="prose prose-lg dark:prose-invert prose-blue max-w-none mb-8 animate-fadeIn"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />
      
      {/* Author Bio */}
      <div className="border-t border-b border-gray-200 dark:border-gray-700 py-8 mt-12">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <img 
            src={post.author.avatar} 
            alt={post.author.name} 
            className="w-20 h-20 rounded-full"
          />
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              About {post.author.name}
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {post.author.bio}
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors">
                Twitter
              </a>
              <a href="#" className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors">
                GitHub
              </a>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
};

export default PostDetail;