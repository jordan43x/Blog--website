import React from 'react';
import { Post } from '../types';
import { Link } from './Link';
import { Clock } from 'lucide-react';

interface PostCardProps {
  post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  return (
    <article className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transform transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={post.imageUrl} 
          alt={post.title} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <div className="absolute top-0 right-0 p-2">
          <span className="inline-block px-3 py-1 text-xs font-semibold text-white bg-blue-600 rounded-full">
            {post.category}
          </span>
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
          <Link to={`/post/${post.id}`} className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
            {post.title}
          </Link>
        </h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{post.excerpt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src={post.author.avatar} 
              alt={post.author.name} 
              className="w-8 h-8 rounded-full mr-2"
            />
            <span className="text-sm text-gray-700 dark:text-gray-300">{post.author.name}</span>
          </div>
          <div className="flex items-center text-gray-500 dark:text-gray-400">
            <Clock size={14} className="mr-1" />
            <span className="text-xs">{post.readingTime} min read</span>
          </div>
        </div>
      </div>
    </article>
  );
};

export default PostCard;