import React from 'react';

interface LinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
}

export const Link: React.FC<LinkProps> = ({ to, children, className = '' }) => {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    // In a real app, this would use a router
    console.log(`Navigating to: ${to}`);
  };

  return (
    <a 
      href={to} 
      onClick={handleClick}
      className={className}
    >
      {children}
    </a>
  );
};