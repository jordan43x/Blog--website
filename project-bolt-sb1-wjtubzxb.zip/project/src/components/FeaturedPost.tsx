import React from 'react';
import { Post } from '../types';
import { Link } from './Link';
import { Clock } from 'lucide-react';

interface FeaturedPostProps {
  post: Post;
}

const FeaturedPost: React.FC<FeaturedPostProps> = ({ post }) => {
  return (
    <article className="relative overflow-hidden rounded-xl shadow-lg transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-xl">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-70 z-10"></div>
      <img 
        src={post.imageUrl} 
        alt={post.title} 
        className="w-full h-[500px] object-cover transition-transform duration-500 hover:scale-105"
      />
      <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
        <div className="flex flex-wrap gap-2 mb-3">
          <span className="inline-block px-3 py-1 text-xs font-semibold text-blue-100 bg-blue-600 rounded-full">
            Featured
          </span>
          <span className="inline-block px-3 py-1 text-xs font-semibold text-gray-100 bg-gray-800/60 backdrop-blur-sm rounded-full">
            {post.category}
          </span>
        </div>
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-3 animate-fadeUp">
          <Link to={`/post/${post.id}`} className="hover:underline">
            {post.title}
          </Link>
        </h2>
        <p className="text-gray-200 mb-4">{post.excerpt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src={post.author.avatar} 
              alt={post.author.name} 
              className="w-10 h-10 rounded-full mr-3 border-2 border-white"
            />
            <div>
              <span className="block text-white font-medium">{post.author.name}</span>
              <span className="block text-gray-300 text-sm">{post.date}</span>
            </div>
          </div>
          <div className="flex items-center text-gray-300">
            <Clock size={16} className="mr-1" />
            <span className="text-sm">{post.readingTime} min read</span>
          </div>
        </div>
      </div>
    </article>
  );
};

export default FeaturedPost;