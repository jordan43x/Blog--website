import React from 'react';
import { Post } from '../types';
import PostCard from './PostCard';

interface PostListProps {
  posts: Post[];
  title?: string;
}

const PostList: React.FC<PostListProps> = ({ posts, title }) => {
  return (
    <section>
      {title && (
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-6">
          {title}
        </h2>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {posts.map((post, index) => (
          <div 
            key={post.id} 
            className="animate-fadeUp" 
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <PostCard post={post} />
          </div>
        ))}
      </div>
    </section>
  );
};

export default PostList;