import React from 'react';
import FeaturedPost from '../components/FeaturedPost';
import PostList from '../components/PostList';
import CategoryList from '../components/CategoryList';
import Newsletter from '../components/Newsletter';
import { posts } from '../data/posts';
import { categories } from '../data/categories';

const HomePage: React.FC = () => {
  const featuredPosts = posts.filter(post => post.featured);
  const recentPosts = posts.filter(post => !post.featured);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
      {/* Hero section */}
      <div className="text-center mb-16 animate-fadeIn">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
          Insight<span className="text-blue-600">Blog</span>
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-gray-600 dark:text-gray-400">
          Exploring the latest trends and insights in web development, design, and technology.
        </p>
      </div>

      {/* Featured post */}
      {featuredPosts.length > 0 && (
        <section className="mb-16 animate-fadeUp">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Featured Post
          </h2>
          <FeaturedPost post={featuredPosts[0]} />
        </section>
      )}

      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
        {/* Posts */}
        <div className="lg:col-span-8">
          <PostList posts={recentPosts} title="Recent Posts" />
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-8">
          <CategoryList categories={categories} />
          
          {/* Popular Tags */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Popular Tags</h3>
            <div className="flex flex-wrap gap-2">
              {Array.from(new Set(posts.flatMap(post => post.tags))).map((tag, index) => (
                <span 
                  key={index}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-full text-sm text-gray-700 dark:text-gray-300 cursor-pointer transition-colors"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
          
          {/* Newsletter Teaser */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-md p-6 text-white">
            <h3 className="text-lg font-semibold mb-2">Stay Updated</h3>
            <p className="mb-4 text-sm opacity-90">
              Subscribe to our newsletter and never miss our latest posts and updates.
            </p>
            <button className="w-full py-2 bg-white text-blue-600 font-medium rounded-lg hover:bg-gray-100 transition-colors">
              Subscribe Now
            </button>
          </div>
        </aside>
      </div>
      
      {/* Newsletter */}
      <Newsletter />
    </div>
  );
};

export default HomePage;