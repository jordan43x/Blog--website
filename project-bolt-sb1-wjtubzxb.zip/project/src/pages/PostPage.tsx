import React from 'react';
import PostDetail from '../components/PostDetail';
import PostList from '../components/PostList';
import { posts } from '../data/posts';

interface PostPageProps {
  postId: string;
}

const PostPage: React.FC<PostPageProps> = ({ postId }) => {
  const post = posts.find(p => p.id === postId);
  
  // Get related posts based on category or tags
  const relatedPosts = posts
    .filter(p => p.id !== postId)
    .filter(p => p.category === post?.category || p.tags.some(tag => post?.tags.includes(tag)))
    .slice(0, 3);
  
  if (!post) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Post Not Found</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            The post you are looking for might have been removed or is temporarily unavailable.
          </p>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Back to Home
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
      <div className="mb-16">
        <PostDetail post={post} />
      </div>
      
      {relatedPosts.length > 0 && (
        <div className="mt-16">
          <PostList posts={relatedPosts} title="Related Posts" />
        </div>
      )}
    </div>
  );
};

export default PostPage;