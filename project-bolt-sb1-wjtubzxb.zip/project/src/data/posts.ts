import { Post } from '../types';

export const posts: Post[] = [
  {
    id: '1',
    title: 'The Future of Web Development',
    excerpt: 'Exploring the latest trends and technologies shaping the future of web development.',
    content: `
      <p>Web development continues to evolve at a rapid pace, with new frameworks, libraries, and methodologies emerging regularly. In this article, we'll explore the most exciting trends that are shaping the future of the field.</p>
      
      <h2>The Rise of JAMstack</h2>
      <p>JAMstack (JavaScript, APIs, and Markup) has gained significant traction in recent years. This architecture provides better performance, higher security, lower cost of scaling, and a better developer experience.</p>
      
      <h2>WebAssembly</h2>
      <p>WebAssembly (Wasm) allows developers to run code written in multiple languages at near-native speed on the web. This technology opens up new possibilities for web applications, including games, video and image editing, and scientific visualizations.</p>
      
      <h2>AI-Driven Development</h2>
      <p>Artificial intelligence and machine learning are increasingly being integrated into development workflows. From code completion to automated testing, AI is transforming how developers work.</p>
      
      <h2>Progressive Web Apps</h2>
      <p>Progressive Web Apps (PWAs) continue to bridge the gap between web and mobile applications. With features like offline functionality, push notifications, and home screen installation, PWAs offer a native-like experience through the web.</p>
      
      <h2>Conclusion</h2>
      <p>The future of web development is exciting and full of possibilities. By staying informed about these trends and adapting to new technologies, developers can create more powerful, efficient, and user-friendly web applications.</p>
    `,
    author: {
      id: '1',
      name: 'Sarah Johnson',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      bio: 'Senior Web Developer with 10+ years of experience in JavaScript frameworks.'
    },
    date: '2025-04-15',
    readingTime: 6,
    category: 'Technology',
    tags: ['Web Development', 'JavaScript', 'Future Tech'],
    imageUrl: 'https://images.pexels.com/photos/1181373/pexels-photo-1181373.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    featured: true
  },
  {
    id: '2',
    title: 'Mastering CSS Grid Layouts',
    excerpt: 'A comprehensive guide to creating complex, responsive layouts with CSS Grid.',
    content: `
      <p>CSS Grid has revolutionized web layout design, providing developers with a powerful two-dimensional system for creating complex layouts with ease.</p>
      
      <h2>Understanding the Basics</h2>
      <p>At its core, CSS Grid Layout is a two-dimensional layout system designed specifically for the web. It allows for content to be organized in rows and columns, making it easier to design web pages without having to use floats and positioning.</p>
      
      <h2>Grid Container and Grid Items</h2>
      <p>In CSS Grid, the parent element becomes the grid container by setting the display property to grid. The child elements automatically become grid items.</p>
      
      <h2>Creating Columns and Rows</h2>
      <p>The grid-template-columns and grid-template-rows properties define the columns and rows of the grid. They can be set using various units like pixels, percentages, or the flexible fr unit.</p>
      
      <h2>Advanced Techniques</h2>
      <p>CSS Grid also offers advanced features like grid-gap for spacing between grid items, and functions like minmax() for responsive designs without media queries.</p>
      
      <h2>Conclusion</h2>
      <p>Mastering CSS Grid enables you to create complex layouts with minimal code, resulting in cleaner, more maintainable stylesheets.</p>
    `,
    author: {
      id: '2',
      name: 'David Chen',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
      bio: 'Frontend Developer and CSS enthusiast.'
    },
    date: '2025-04-08',
    readingTime: 8,
    category: 'CSS',
    tags: ['CSS', 'Web Design', 'Responsive Design'],
    imageUrl: 'https://images.pexels.com/photos/196646/pexels-photo-196646.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    featured: false
  },
  {
    id: '3',
    title: 'React Hooks: Beyond the Basics',
    excerpt: 'Dive deeper into React Hooks with advanced patterns and custom implementations.',
    content: `
      <p>React Hooks have transformed how we write React components, enabling function components to use state and lifecycle features previously only available in class components.</p>
      
      <h2>Custom Hooks</h2>
      <p>One of the most powerful features of Hooks is the ability to create custom Hooks, allowing you to extract component logic into reusable functions.</p>
      
      <h2>useReducer for Complex State</h2>
      <p>While useState is perfect for simple state management, useReducer provides a more structured approach for managing complex state logic.</p>
      
      <h2>useCallback and useMemo</h2>
      <p>These performance-oriented Hooks help prevent unnecessary re-renders by memoizing functions and values.</p>
      
      <h2>Context with useContext</h2>
      <p>The useContext Hook makes it easier to consume context in your components, providing a cleaner alternative to Context.Consumer.</p>
      
      <h2>Conclusion</h2>
      <p>Mastering advanced Hook patterns allows you to write more maintainable, efficient React code while avoiding common pitfalls.</p>
    `,
    author: {
      id: '1',
      name: 'Sarah Johnson',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      bio: 'Senior Web Developer with 10+ years of experience in JavaScript frameworks.'
    },
    date: '2025-03-28',
    readingTime: 10,
    category: 'React',
    tags: ['React', 'JavaScript', 'Hooks'],
    imageUrl: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    featured: true
  },
  {
    id: '4',
    title: 'Optimizing Web Performance',
    excerpt: 'Essential techniques to improve loading times and overall performance of your websites.',
    content: `
      <p>Web performance optimization is critical for providing a good user experience. Faster websites lead to better engagement, higher conversion rates, and improved SEO rankings.</p>
      
      <h2>Image Optimization</h2>
      <p>Images often account for most of the downloaded bytes on a webpage. Using modern formats like WebP, implementing lazy loading, and properly sizing images can significantly reduce load times.</p>
      
      <h2>Code Splitting</h2>
      <p>Breaking your JavaScript bundle into smaller chunks allows users to download only what they need for the current page, reducing initial load times.</p>
      
      <h2>Caching Strategies</h2>
      <p>Implementing appropriate caching strategies ensures that returning visitors don't have to download the same resources repeatedly.</p>
      
      <h2>Minimizing Third-Party Impact</h2>
      <p>Third-party scripts can significantly impact performance. Audit your third-party dependencies regularly and load them efficiently.</p>
      
      <h2>Conclusion</h2>
      <p>Performance optimization is an ongoing process. Regularly measuring and improving your website's performance is essential for providing the best possible user experience.</p>
    `,
    author: {
      id: '3',
      name: 'Michael Zhang',
      avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150',
      bio: 'Performance Engineer specializing in web optimization techniques.'
    },
    date: '2025-03-20',
    readingTime: 7,
    category: 'Performance',
    tags: ['Web Performance', 'Optimization', 'User Experience'],
    imageUrl: 'https://images.pexels.com/photos/1779487/pexels-photo-1779487.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    featured: false
  }
];