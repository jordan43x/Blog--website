import { Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Technology',
    slug: 'technology',
  },
  {
    id: '2',
    name: 'CSS',
    slug: 'css',
  },
  {
    id: '3',
    name: 'React',
    slug: 'react',
  },
  {
    id: '4',
    name: 'Performance',
    slug: 'performance',
  },
  {
    id: '5',
    name: 'JavaScript',
    slug: 'javascript',
  },
  {
    id: '6',
    name: 'Design',
    slug: 'design',
  }
];