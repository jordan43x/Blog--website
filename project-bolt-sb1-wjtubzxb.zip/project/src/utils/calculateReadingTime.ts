export const calculateReadingTime = (content: string): number => {
  // Average reading speed: 225 words per minute
  const wordsPerMinute = 225;
  const wordCount = content.trim().split(/\s+/).length;
  const readingTime = Math.ceil(wordCount / wordsPerMinute);
  
  // Minimum reading time of 1 minute
  return Math.max(1, readingTime);
};