import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import PostPage from './pages/PostPage';
import { useDarkMode } from './hooks/useDarkMode';

function App() {
  const [isDark, toggleDarkMode] = useDarkMode();
  const [currentPage, setCurrentPage] = useState('home');
  const [currentPostId, setCurrentPostId] = useState<string | null>(null);

  // Simple router
  useEffect(() => {
    const handleNavigation = () => {
      const path = window.location.pathname;
      
      if (path === '/' || path === '') {
        setCurrentPage('home');
        setCurrentPostId(null);
      } else if (path.startsWith('/post/')) {
        setCurrentPage('post');
        setCurrentPostId(path.split('/').pop() || '1');
      }
    };
    
    // Listen for popstate events (back/forward navigation)
    window.addEventListener('popstate', handleNavigation);
    
    // Initial navigation
    handleNavigation();
    
    return () => {
      window.removeEventListener('popstate', handleNavigation);
    };
  }, []);

  // Update document title based on current page
  useEffect(() => {
    document.title = currentPage === 'home' ? 'InsightBlog - Web Development Insights' : 'Article - InsightBlog';
  }, [currentPage]);

  return (
    <div className={`min-h-screen ${isDark ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
        <Header isDark={isDark} toggleDarkMode={toggleDarkMode} />
        
        <main>
          {currentPage === 'home' && <HomePage />}
          {currentPage === 'post' && currentPostId && <PostPage postId={currentPostId} />}
        </main>
        
        <Footer />
      </div>
    </div>
  );
}

export default App;